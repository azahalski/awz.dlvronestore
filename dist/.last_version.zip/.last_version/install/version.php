<?
$arModuleVersion = array(
	"VERSION" => "1.0.3",
	"VERSION_DATE" => "2026-02-23 01:28:00"
);
?>