<?php

namespace Awz\Dlvronestore;

class Helper {

    const MODULE_ID = 'awz.dlvronestore';

}